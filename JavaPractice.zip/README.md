# ☕ Java Weekly Practice Programs

Welcome to my **Java Practice Repository**!  
This repo contains all my **weekly Java programs**, neatly organized by folders such as `week1`, `week2`, etc.  
Each week covers fundamental to intermediate Java concepts — from data types to loops, arrays, and real-time exercises.

---

## 📁 Folder Structure

```
JavaPractice/
├── week1/
│   ├── firstprogram.java
│   └── datatype.java
└── README.md
```

---

## 🧠 Topics Covered

| Week | Topics Practiced | Example Programs |
|------|------------------|------------------|
| Week 1 | Basic Syntax, Data Types, Print Statements | `firstprogram.java`, `datatype.java` |
| Week 2 | Conditional Statements (if, else, switch) | Coming soon... |
| Week 3 | Loops (for, while, do-while) | Coming soon... |
| Week 4 | Arrays and Strings | Coming soon... |
| Week 5 | Methods, Constructors, and OOP Basics | Coming soon... |

---

## ⚙️ How to Run Java Programs

### Option 1: Using **Command Prompt / Terminal**
1. Navigate to the respective week folder:
   ```bash
   cd week1
   ```
2. Compile the Java file:
   ```bash
   javac firstprogram.java
   ```
3. Run the program:
   ```bash
   java firstprogram
   ```

### Option 2: Using **Visual Studio Code / Eclipse**
- Open the project folder in the IDE.
- Right-click the Java file → **Run Java Program**.
- The output will appear in the terminal section.

---

## 🧑‍💻 About the Author

**👋 Hi, I’m Ashwanth C**  
🎓 B.Tech in Electrical and Electronics Engineering (EEE), 2025 – SASTRA University  
💡 Currently learning **Manual & Automation Testing** at **TestLeaf**  
💻 Passionate about **Software Testing, Java Programming, and Backend Development**  

This repository is part of my continuous learning journey — I regularly update it with new Java exercises every week.

---

## 🌟 Future Plans

- Add more real-world Java mini-projects  
- Include code comments and explanations  
- Implement unit tests using JUnit  
- Create small automation or backend integrations using Java  

---

⭐ *If you found this helpful or inspiring, please give it a star on GitHub!* ⭐
