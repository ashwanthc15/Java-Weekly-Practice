package week1;

public class firstprogram {
    public static void main(String[] args) {
        float browserVersion = 100.2f;
        String browserVersion1 = "firefox";
        boolean isVisible = true;
        int releaseYear = 1998;
        char browserLogo = 'f';
        
        System.out.println("Browser Version: " + browserVersion);
        System.out.println("Browser Name: " + browserVersion1);
        System.out.println("Is Visible: " + isVisible);
        System.out.println("Release Year: " + releaseYear);
        System.out.println("Browser Logo: " + browserLogo);
    }
}
